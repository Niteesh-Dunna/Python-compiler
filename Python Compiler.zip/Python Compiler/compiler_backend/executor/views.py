from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
import tempfile
import subprocess
import os

@api_view(['POST'])
def execute_code(request):
    code = request.data.get('code', '')
    user_input = request.data.get('input', '')

    with tempfile.NamedTemporaryFile(delete=False, suffix='.py', mode='w') as tmp:
        tmp.write(code)
        tmp_path = tmp.name

    try:
        result = subprocess.run(
            ['python3', tmp_path],
            input=user_input.encode(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5
        )
        output = result.stdout.decode() + result.stderr.decode()
    except subprocess.TimeoutExpired:
        output = "Execution timed out."
    except Exception as e:
        output = str(e)
    finally:
        os.remove(tmp_path)

    return Response({'output': output}, status=status.HTTP_200_OK)
