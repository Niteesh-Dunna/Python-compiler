from django.urls import path
from .views import execute_code

urlpatterns = [
    path('api/execute-code/', execute_code),
]
