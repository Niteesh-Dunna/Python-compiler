import React from "react";
import PythonCompiler from "./components/Pythoncompiler";

const App = () => {
  return (
    <div>
      <PythonCompiler />
    </div>
  );
};

export default App;
