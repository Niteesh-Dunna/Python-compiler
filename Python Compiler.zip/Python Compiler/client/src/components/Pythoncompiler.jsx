// PythonCompiler.jsx
import React, {
  useState,
  useRef,
  useEffect,
  forwardRef,
  useImperativeHandle,
} from "react";
import PropTypes from "prop-types";
import { EditorView, keymap } from "@codemirror/view";
import { EditorState } from "@codemirror/state";
import { python } from "@codemirror/lang-python";
import { oneDark } from "@codemirror/theme-one-dark";
import "./PythonCompiler.css"; // Your CSS file

const PythonCompiler = forwardRef(({ initialCode = "" }, ref) => {
  const [output, setOutput] = useState(">>> Ready to execute Python code");
  const [isLoading, setIsLoading] = useState(false);
  const [inputCount, setInputCount] = useState(0);
  const editorRef = useRef(null);
  const editorViewRef = useRef(null);
  const inputTextareaRef = useRef(null);

  useEffect(() => {
    const state = EditorState.create({
      doc: initialCode || 'print("Hello, World!")',
      extensions: [
        python(),
        oneDark,
        keymap.of([
          {
            key: "Shift-Enter",
            run: () => {
              handleRunCode();
              return true;
            },
          },
        ]),
      ],
    });

    editorViewRef.current = new EditorView({
      state,
      parent: editorRef.current,
    });

    return () => editorViewRef.current?.destroy();
  }, []);

  const handleRunCode = async () => {
    const code = editorViewRef.current.state.doc.toString();
    const matches = code.match(/input\(/g);
    const count = matches ? matches.length : 0;
    setInputCount(count);

    if (count > 0) {
      setOutput(`>>> Please enter ${count} input(s):`);
      setTimeout(() => inputTextareaRef.current?.focus(), 0);
      return;
    }

    runBackend(code);
  };

  const runBackend = async (code, inputs = "") => {
    setIsLoading(true);
    setOutput(">>> Running...");
    try {
      const res = await fetch("http://127.0.0.1:8000/api/execute-code/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, input: inputs }),
      });
      const data = await res.json();
      setOutput(data.output || data.error || ">>> No output");
    } catch (err) {
      setOutput(">>> Failed to connect to backend");
    } finally {
      setIsLoading(false);
      setInputCount(0);
    }
  };

  const handleSubmitInputs = () => {
    const input = inputTextareaRef.current?.value || "";
    runBackend(editorViewRef.current.state.doc.toString(), input);
  };

  useImperativeHandle(ref, () => ({
    runCode: handleRunCode,
  }));

  return (
    <div className="compiler-fullscreen">
      <div className="panel editor-panel">
        <div className="panel-header">
          <h2>Editor</h2>
          <button onClick={handleRunCode} disabled={isLoading}>
            {isLoading ? "Running..." : "Run (Shift+Enter)"}
          </button>
        </div>
        <div ref={editorRef} className="editor-box" />
      </div>

      <div className="panel output-panel">
        <div className="panel-header">
          <h2>Output</h2>
        </div>
        <div className="output-box">
          <pre>{output}</pre>
          {inputCount > 0 && (
            <div className="input-section">
              <textarea
                ref={inputTextareaRef}
                placeholder={`Enter ${inputCount} input(s)...`}
              />
              <button onClick={handleSubmitInputs}>Submit Inputs</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
});

PythonCompiler.propTypes = {
  initialCode: PropTypes.string,
};

export default PythonCompiler;
